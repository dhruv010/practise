package Pakg_sikuli;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.FindFailed;		//Download link: https://launchpad.net/raiman/sikulix2013+/1.1.0 ;
import org.sikuli.script.Pattern;

import org.sikuli.script.Screen;




public class Sikuli_Test {

	public static void main(String[] args) throws FindFailed, Exception {
		
		
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver_win32\\chromedriver.exe ");
		
		System.getProperty("user.dir");
		String filepath_OpenButton = "D:\\Dhruv\\BitBucket_Automation\\Sikuli_Proj\\Target\\BulkUpload\\"; 			//FullScreen.png";
        String inputField_img = "D:\\Dhruv\\BitBucket_Automation\\Sikuli_Proj\\Target\\BulkUpload\\FilePathInput.png";
        String path="D:\\Dhruv\\BitBucket_Automation\\Sikuli_Proj\\Target\\BulkUpload\\"; //Dv.csv";
     
		Screen s= new Screen();
			
		Pattern openBtn=new Pattern(filepath_OpenButton +"OpenButton.png");
		Pattern FilInputPathInput=new Pattern(inputField_img);
		
		WebDriver driver = new ChromeDriver();		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.MILLISECONDS);
		driver.manage().window().maximize();
	
	
		driver.get("https:\\connectv2-stg.condecodev.com\\SelfService");
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("logonIdentifier")));
		driver.findElement(By.id("logonIdentifier")).sendKeys("dhruv.sharma@condecosoftware.com");
		driver.findElement(By.id("password")).sendKeys("Dhruv@321");
		driver.findElement(By.id("next")).click();
	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Users')]")));		
		driver.findElement(By.xpath("//span[contains(text(),'Users')]")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Bulk upload')]")).click();
		driver.findElement(By.xpath("//span[@class='btn chooseFileBtn']")).click();
	
		
		
		Thread.sleep(2000);
		s.type(FilInputPathInput,path+ "Dv.csv");

		s.click(openBtn);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='btn uploadButton']")));
		driver.findElement(By.xpath("//button[@class='btn uploadButton']")).click(); //Click on Upload button
		
		driver.close();
		System.out.println("Test case passed: ");
		
	}

}

