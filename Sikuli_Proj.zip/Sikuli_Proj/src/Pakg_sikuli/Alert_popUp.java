package Pakg_sikuli;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Event_Packages.Events;




public class Alert_popUp {

	public static void main(String[] args) throws Exception {
		
		
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver_win32\\chromedriver.exe ");
		
		WebDriver driver = new ChromeDriver();		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.MILLISECONDS);
		driver.manage().window().maximize();
	
	
		driver.get("https:\\connectv2-stg.condecodev.com\\SelfService");
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("logonIdentifier")));
		driver.findElement(By.id("logonIdentifier")).sendKeys("dhruv.sharma@condecosoftware.com");
		driver.findElement(By.id("password")).sendKeys("Dhruv@321");
		driver.findElement(By.id("next")).click();
	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Users')]")));		
		driver.findElement(By.xpath("//span[contains(text(),'Users')]")).click();


		//JavascriptExecutor js = (JavascriptExecutor) driver;
		//js.executeScript("window.scrollBy(0,400)");
		Events obj=new Events();
		
		obj.Scroll(driver);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//tbody//tr[6]//td[6]//button[1]")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Cancel')]")));
		driver.findElement(By.xpath("//button[contains(text(),'Cancel')]")).click();
		Thread.sleep(2000);
		obj.ScreenShot(driver,"D:\\Dhruv\\BitBucket_Automation\\Sikuli_Proj\\Target\\BulkUpload\\img.png");
		Thread.sleep(2000);
	
		
		driver.close();
		System.out.println("Test case passed: ");
		
	}

	}


