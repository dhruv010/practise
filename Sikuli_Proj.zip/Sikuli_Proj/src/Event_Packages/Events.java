package Event_Packages;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Events {
	
		
	public   void Scroll( WebDriver driver1)
	{
		JavascriptExecutor js = (JavascriptExecutor)driver1;
		  js.executeScript("window.scrollBy(0,400)");
		//js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		//js.executeScript("window.scrollBy(0,-240)");
		
	}
	
	public void ScreenShot(WebDriver driver, String FilePath) throws IOException {
		
			File scrnFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			File file1    = new File(FilePath);
			FileUtils.copyFile(scrnFile, file1);	
	}
	
	
	
	
	

}
